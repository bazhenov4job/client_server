
PRESENCE = 'presence'
BYTES_TO_READ = 128
PORT = 7777
HOST = 'localhost'
ALLOWED_USERS = {
    "guest": "password"
}
LISTEN = ''

